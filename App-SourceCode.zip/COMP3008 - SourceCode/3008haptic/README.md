### COMP 3000 - Rhythmic Authentication

- Fill this area as you please...

#### Dependencies
 - [Android Studio](https://developer.android.com/studio/index.html)
 - Oracle JDK or OpenJDK 8.0
 - ADB tools (Usually included with Android Studio)
 
