package com.a3008project.test.a3008_haptic;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Secrets extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secrets);
    }
}
