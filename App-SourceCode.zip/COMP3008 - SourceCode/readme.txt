This project was built in Android Studio.
In order to compile and run this project you need:

 - Java Development Kit 8.0+ 
 - Android Software Development Kit (API 20 - 26)
 - Android Studio
 - Android Device or a Android Virtual Device

